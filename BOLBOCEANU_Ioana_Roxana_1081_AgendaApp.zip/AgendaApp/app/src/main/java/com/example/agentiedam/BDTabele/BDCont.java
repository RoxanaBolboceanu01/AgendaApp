package com.example.agentiedam.BDTabele;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BDCont extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "agenda.db";
    private static final String TABLE_NAME_UTILIZATORI = "UTILIZATORI_TABLE";
    private static final String COL_1 = "ID_UTILIZATOR";
    private static final String COL_2 = "EMAIL";
    private static final String COL_3 = "PAROLA";
    private static final String COL_4 = "PAROLACONFIRMATA";

    public BDCont(Context context) {
        super(context, DATABASE_NAME, null,10 );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME_UTILIZATORI + " (" + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_2 + " TEXT, " + COL_3 + " TEXT, " + COL_4 + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_UTILIZATORI);
        onCreate(db);
    }

    public boolean insereazaDate(String email, String parola) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2, email);
        values.put(COL_3, parola);

        long result = db.insert(TABLE_NAME_UTILIZATORI, null, values);
        return result != -1;
    }

    public boolean verificaEmail(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME_UTILIZATORI + " WHERE " + COL_2 + "=?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean verificaEmailParola(String email, String parola) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME_UTILIZATORI + " WHERE " + COL_2 + "=? AND " + COL_3 + "=?", new String[]{email, parola});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}
