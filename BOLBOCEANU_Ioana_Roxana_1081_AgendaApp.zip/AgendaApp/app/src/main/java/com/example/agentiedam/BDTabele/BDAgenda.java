package com.example.agentiedam.BDTabele;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.agentiedam.Model.AgendaModel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BDAgenda  extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;

    private SQLiteDatabase db;
    private static final String DATABASE_NAME = "agenda.db";
    public static final String TABLE_NAME = "AGENDA_TABLE";
    public static final String COL_1 = "ID";
    private static final String COL_2 = "TITLU";
    private static final String COL_3 = "DATA";
    private static final String COL_4 = "DESCRIERE";
    public static final String COL_7 = "LOCATIE";
    private static final String COL_6 = "STATUS";


    public BDAgenda(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 10);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "("
                + "ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "ID_UTILIZATOR INTEGER REFERENCES TABLE_NAME_UTILIZATORI(ID_UTILIZATOR),"
                + "TITLU TEXT, DATA INTEGER, DESCRIERE TEXT, LOCATIE TEXT, STATUS INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       // db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
       // onCreate(db);

        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE AGENDA_TABLE ADD COLUMN LOCATIE TEXT");
        }

    }
    public void insereazaInAgenda(AgendaModel model) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2, model.getTitlu());
        if (model.getData() != null) {
            values.put(COL_3, model.getData().getTime());
        } else {
            values.put(COL_3, (Long) null);
        }
        values.put(COL_4, model.getDescriere());
        values.put(COL_7, model.getLocatie());
        values.put(COL_6, 0);
        db.insert(TABLE_NAME, null, values);
    }

    public void actualizeazaAgenda(int id, String titlu, Date data, String descriere, String locatie) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2, titlu);
        values.put(COL_3, data.getTime());
        values.put(COL_4, descriere);
        values.put(COL_7, locatie);
        db.update(TABLE_NAME, values, "ID=?", new String[]{String.valueOf(id)});
    }

    public void actualizeazaStatus(int id, int status) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_6, status);
        db.update(TABLE_NAME, values, "ID=?", new String[]{String.valueOf(id)});
    }

    public void sterge(int id) {
        db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "ID=?", new String[]{String.valueOf(id)});
    }

    @SuppressLint("Range")
    public List<AgendaModel> getAgenda() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<AgendaModel> agendaML = new ArrayList<>();


        try (Cursor cursor = db.query(
                "AGENDA_TABLE",
                null,
                null,
                null,
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    AgendaModel agendaModel = new AgendaModel();
                    agendaModel.setId(cursor.getInt(cursor.getColumnIndex(COL_1)));
                    agendaModel.setTitlu(cursor.getString(cursor.getColumnIndex(COL_2)));
                    agendaModel.setData(new Date(cursor.getLong(cursor.getColumnIndex(COL_3))));
                    agendaModel.setDescriere(cursor.getString(cursor.getColumnIndex(COL_4)));
                    agendaModel.setLocatie(cursor.getString(cursor.getColumnIndex(COL_7)));
                    agendaModel.setStatus(cursor.getInt(cursor.getColumnIndex(COL_6)));
                    agendaML.add(agendaModel);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return agendaML;
    }




    public List<String> getSpinnerOptions() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<String> options = new ArrayList<String>();
        String query = "SELECT DISTINCT " + COL_7 + " FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                options.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return options;
    }


    public List<String> getSpinnerOptionsAsList() {
        List<String> spinnerOptions = getSpinnerOptions();
        return spinnerOptions;
    }

    @SuppressLint("Range")
    public List<AgendaModel> getAgendaSortedByDate() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<AgendaModel> agendaModelList = new ArrayList<>();

        try (Cursor cursor = db.query(
                "AGENDA_TABLE",
                null,
                null,
                null,
                null,
                null,
                "DATA ASC"
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    AgendaModel agendaM = new AgendaModel();
                    agendaM.setId(cursor.getInt(cursor.getColumnIndex(COL_1)));
                    agendaM.setTitlu(cursor.getString(cursor.getColumnIndex(COL_2)));
                    agendaM.setData(new Date(cursor.getLong(cursor.getColumnIndex(COL_3))));
                    agendaM.setDescriere(cursor.getString(cursor.getColumnIndex(COL_4)));
                    agendaM.setLocatie(cursor.getString(cursor.getColumnIndex(COL_7)));
                    agendaM.setStatus(cursor.getInt(cursor.getColumnIndex(COL_6)));
                    agendaModelList.add(agendaM);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return agendaModelList;
    }
    @SuppressLint("Range")
    public List<AgendaModel> getAgendaFiltrata(String locatieSelectata) {
        SQLiteDatabase db = this.getWritableDatabase();
        List<AgendaModel> agendaModelList = new ArrayList<>();

        try (Cursor cursor = db.query(
                "AGENDA_TABLE",
                null,
                "LOCATIE=?",
                new String[] {locatieSelectata},
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    AgendaModel agendaM = new AgendaModel();
                    agendaM.setId(cursor.getInt(cursor.getColumnIndex(COL_1)));
                    agendaM.setTitlu(cursor.getString(cursor.getColumnIndex(COL_2)));
                    agendaM.setData(new Date(cursor.getLong(cursor.getColumnIndex(COL_3))));
                    agendaM.setDescriere(cursor.getString(cursor.getColumnIndex(COL_4)));
                    agendaM.setLocatie(cursor.getString(cursor.getColumnIndex(COL_7)));
                    agendaM.setStatus(cursor.getInt(cursor.getColumnIndex(COL_6)));
                    agendaModelList.add(agendaM);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return agendaModelList;
    }
}

