package com.example.agentiedam;

import android.content.Context;
import android.content.SharedPreferences;

public class Preferinte {
    private SharedPreferences sharedPreferences;

    public Preferinte(Context context) {
        this.sharedPreferences = context.getSharedPreferences("agenda_pref", Context.MODE_PRIVATE);
    }

    public SharedPreferences getSharedPreferences() {
        return sharedPreferences;
    }

    public void setSharedPreferences(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    public void scrieDatePreferinte() {
        SharedPreferences preferences = sharedPreferences;
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("color", "magenta");
        editor.putInt("frequency", 10);
        editor.putFloat("fontsize", 14.0f);
        editor.apply();
    }

    public void citesteDatePreferinte() {
        SharedPreferences preferences = sharedPreferences;
        String color = preferences.getString("color", "");
        int frequency = preferences.getInt("frequency", 0);
        float fontSize = preferences.getFloat("fontsize", 12.0f);


    }



}