package com.example.agentiedam.Activitati;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

import com.example.agentiedam.AdaugaAgenda;
import com.example.agentiedam.AgendaAdapter;
import com.example.agentiedam.Model.AgendaModel;
import com.example.agentiedam.BDTabele.BDAgenda;
import com.example.agentiedam.BDTabele.BDCont;
import com.example.agentiedam.Dialog;
import com.example.agentiedam.OptiuniAgenda;
import com.example.agentiedam.Preferinte;
import com.example.agentiedam.Model.ProfilModel;
import com.example.agentiedam.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AgendaActivity extends AppCompatActivity implements Dialog {
    private Preferinte preferinte;
    private RecyclerView rec_agenda;
    private FloatingActionButton fab;
    private BDAgenda bd;
    private List<AgendaModel> list;
    private AgendaAdapter adapter;

    Spinner spAgendaFiltrata;
    CheckBox checkBox;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);

        BDCont db1 = new BDCont(getApplicationContext());
        SQLiteDatabase db = db1.getWritableDatabase();
        rec_agenda = findViewById(R.id.recyclerview);
        preferinte = new Preferinte(this);
        checkBox = findViewById(R.id.check_agenda);
        preferinte.scrieDatePreferinte();
        preferinte.citesteDatePreferinte();




        SharedPreferences preferences = preferinte.getSharedPreferences();
        String colorValue = preferences.getString("color", String.valueOf(Color.MAGENTA));
        rec_agenda.setBackgroundColor(Color.parseColor(colorValue));



        fab = findViewById(R.id.fab_btn);
        bd = new BDAgenda(AgendaActivity.this);

        list = new ArrayList<>();
        adapter = new AgendaAdapter(bd,AgendaActivity.this);

        rec_agenda.setHasFixedSize(true);


        list = bd.getAgenda();
        Collections.reverse(list);
        adapter.setAgenda(list);
        rec_agenda.setAdapter(adapter);
        rec_agenda.setLayoutManager(new LinearLayoutManager(this));


        Button sortButton = findViewById(R.id.btn_filtrare);
        sortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list = bd.getAgendaSortedByDate();
                adapter.updateData(list);

            }
        });

        spAgendaFiltrata = findViewById(R.id.sp_agendaFiltrata);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.locations_array, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spAgendaFiltrata.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String locatieSelectata = parent.getItemAtPosition(position).toString();
                if (locatieSelectata.equals("Selecteaza o optiune...")) {
                    list = bd.getAgenda();
                } else {
                    list =bd.getAgendaFiltrata(locatieSelectata);
                }
                adapter.setAgenda(list);
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                list = bd.getAgenda();
                adapter.setAgenda(list);
                adapter.notifyDataSetChanged();
            }
        });

                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        AdaugaAgenda.instantaNoua().show(getSupportFragmentManager(), AdaugaAgenda.TAG);
                    }
                });
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new OptiuniAgenda(adapter));
        itemTouchHelper.attachToRecyclerView(rec_agenda);



    }

    private void filtrareAgenda(String locatieSelectata) {
        list = bd.getAgendaFiltrata(locatieSelectata);
        adapter.setAgenda(list);
        adapter.notifyDataSetChanged();
    }


    @Override
    public void dialogClose(DialogInterface dialogInterface) {

        list = bd.getAgenda();
        Collections.reverse(list);
        adapter.setAgenda(list);
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.meniu_profil) {
            ProfilModel profil = new ProfilModel("CSIE", "An 3", 1081, "Dispozitive si aplicatii mobile", "Agenda / sincronizare online");
            Intent intent = new Intent(this, ProfilActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("profil", profil);
            intent.putExtras(bundle);
            String email = getIntent().getStringExtra("email");
            intent.putExtra("email",email);

            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_agenda) {
            Intent intent = new Intent(this, AgendaActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_istoric) {
            Intent intent = new Intent(this, IstoricActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_deconectare) {
            Intent intent = new Intent(this, DeconectareActivity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}