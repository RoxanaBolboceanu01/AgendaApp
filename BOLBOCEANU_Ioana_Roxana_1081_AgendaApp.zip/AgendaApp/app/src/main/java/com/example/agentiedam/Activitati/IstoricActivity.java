package com.example.agentiedam.Activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;

import com.example.agentiedam.Model.ProfilModel;
import com.example.agentiedam.Preferinte;
import com.example.agentiedam.R;
import com.example.agentiedam.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class IstoricActivity extends AppCompatActivity {
    private Preferinte preferinte;

    ActivityMainBinding binding;

    private ArrayList<String> istoricList = new ArrayList<>();

    ArrayAdapter<String> listAdapter;

    Handler handler = new Handler();
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initializeazaLista();
        binding.btnJson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new incarcaDate().start();
            }
        });

    }

    private void initializeazaLista() {
        listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,istoricList);
        binding.lvJson.setAdapter(listAdapter);

    }
    class incarcaDate extends Thread {

        String data = "";

        @Override
        public void run() {

            handler.post(new Runnable() {
                @Override
                public void run() {
                    progressDialog = new ProgressDialog(IstoricActivity.this);
                    progressDialog.setMessage("Se incarca datele");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }
            });

          try {
              URL url = new URL("https://pastebin.com/raw/kSSWhv3E");
              HttpURLConnection httpURLConnection =(HttpURLConnection) url.openConnection();
              InputStream inputStream = httpURLConnection.getInputStream();
              BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
              String linie;


              while((linie = bufferedReader.readLine()) != null) {
                  data = data + linie;
              }

              if(!data.isEmpty()) {
                  JSONObject jsonObject = new JSONObject(data);
                  JSONArray istoricEvenimente = jsonObject.getJSONArray("Istoric");


                  istoricList.clear();
                  for (int i = 0; i < istoricEvenimente.length(); i++) {
                      JSONObject eveniment = istoricEvenimente.getJSONObject(i);
                      int idIstoric = eveniment.getInt("id");
                      String titluIstoric = eveniment.getString("titlu");
                      JSONObject detaliuImportant = eveniment.getJSONObject("detaliuImportant");
                      String locatieIstoric = detaliuImportant.getString("locatie");
                      String dataIstoric = detaliuImportant.getString("data");
                      JSONObject participant = detaliuImportant.getJSONObject("participant");
                      String numeParticipant = participant.getString("nume");
                      String emailParticipant = participant.getString("email");
                      int varstaParticipant = participant.getInt("varsta");

                      istoricList.add(Integer.toString(idIstoric));
                      istoricList.add(titluIstoric);
                      istoricList.add(locatieIstoric);
                      istoricList.add(dataIstoric);
                      istoricList.add(numeParticipant);
                      istoricList.add(emailParticipant);
                      istoricList.add(Integer.toString(varstaParticipant));

                  }
              }
          } catch(MalformedURLException e) {
              e.printStackTrace();
          } catch (IOException e) {
              e.printStackTrace();
          } catch (JSONException e) {
              e.printStackTrace();
          }

          handler.post(new Runnable() {
              @Override
              public void run() {
                  if(progressDialog.isShowing())
                      progressDialog.dismiss();
                  listAdapter.notifyDataSetChanged();
              }
          });
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.meniu_profil) {
            ProfilModel profil = new ProfilModel("CSIE", "An 3", 1081, "Dispozitive si aplicatii mobile", "Agenda / sincronizare online");
            Intent intent = new Intent(this, ProfilActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("profil", profil);
            intent.putExtras(bundle);
            String email = getIntent().getStringExtra("email");
            intent.putExtra("email",email);

            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_agenda) {
            Intent intent = new Intent(this, AgendaActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_istoric) {
            Intent intent = new Intent(this, IstoricActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_deconectare) {
            Intent intent = new Intent(this, DeconectareActivity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

}
