package com.example.agentiedam;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.agentiedam.BDTabele.BDAgenda;
import com.example.agentiedam.Model.AgendaModel;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdaugaAgenda extends BottomSheetDialogFragment {

    public static final String TAG = "Adauga";

    private EditText titlu, descriere;
    private DatePicker data;
    private Button btnSalveaza;
    private Spinner spinnerAg;
    private BDAgenda bd;

    private List<AgendaModel> list;
    private AgendaAdapter adapter;
    FirebaseFirestore firebaseFirestore;

    public static AdaugaAgenda instantaNoua() {
        return  new AdaugaAgenda();
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.adauga_agendalayout,container,false);
        return v;


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        titlu = view.findViewById(R.id.etNume_agenda);
        data = view.findViewById(R.id.dp_agenda);
        data.setCalendarViewShown(false);
        data.setSpinnersShown(true);
        int year = data.getYear();
        int month = data.getMonth();
        int day = data.getDayOfMonth();
        data.updateDate(year,month,day);
        descriere = view.findViewById(R.id.etDescriere_agenda);
        btnSalveaza = view.findViewById(R.id.button_save);
        spinnerAg = view.findViewById(R.id.sp_agenda);
        bd = new BDAgenda(getActivity());

        boolean isUpdate = false;

        Bundle bundle = getArguments();
        if (bundle != null) {
            isUpdate = true;
            String mTitlu = bundle.getString("titlu");
            titlu.setText(mTitlu);
            String mData = bundle.getString("data");
            DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.getDefault());
            try {
                Date date = dateFormat.parse(mData);
                long millis = date.getTime();
                data.setMaxDate(millis);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String mDescriere = bundle.getString("descriere");
            descriere.setText(mDescriere);
            if(mTitlu.length()>0) {
                btnSalveaza.setEnabled(false);
            }
            spinnerAg.setAdapter(spinnerAg.getAdapter());
        }

        titlu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(s.toString().equals("")) {
                    btnSalveaza.setEnabled(false);
                    btnSalveaza.setBackgroundColor(Color.GRAY);
                } else {
                    btnSalveaza.setEnabled(true);
                    btnSalveaza.setBackgroundColor(getResources().getColor(com.google.android.material.R.color.design_default_color_primary));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        final boolean finalIsUpdate = isUpdate;

        list = new ArrayList<>();
        adapter = new AgendaAdapter(getActivity(),list);
        btnSalveaza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = titlu.getText().toString();
                int year = data.getYear();
                int month = data.getMonth();
                int day = data.getDayOfMonth();

                AgendaModel newAgendaModel = new AgendaModel();
                newAgendaModel.setTitlu(titlu.getText().toString());
                newAgendaModel.setDescriere(descriere.getText().toString());
                newAgendaModel.setData(new Date(System.currentTimeMillis()));
                newAgendaModel.setLocatie(spinnerAg.getSelectedItem().toString());
                firebaseFirestore = FirebaseFirestore.getInstance();


                firebaseFirestore.collection("Agenda")
                        .add(newAgendaModel)
                        .addOnSuccessListener(documentReference -> {
                            Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                        })
                        .addOnFailureListener(e -> {
                            Log.w(TAG, "Error adding document", e);
                        });
                if (finalIsUpdate) {
                    bd.actualizeazaAgenda(bundle.getInt("id"), text, null, null,null);
                } else {

                    AgendaModel item = new AgendaModel();
                    item.setTitlu(titlu.getText().toString());

                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year, month, day);
                    data.updateDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

                    if (calendar.get(Calendar.YEAR) == data.getYear() &&
                            calendar.get(Calendar.MONTH) == data.getMonth() &&
                            calendar.get(Calendar.DAY_OF_MONTH) == data.getDayOfMonth()) {

                        Date date = calendar.getTime();

                        item.setData(date);
                        item.setTitlu(titlu.getText().toString());
                        item.setDescriere(descriere.getText().toString());
                        String locatie = spinnerAg.getSelectedItem().toString();
                        item.setLocatie(locatie);
                        item.setStatus(0);
                        bd.insereazaInAgenda(item);
                    } else {
                        Toast.makeText(getContext(), "Data selectată nu este validă", Toast.LENGTH_SHORT).show();
                    }
                }
                dismiss();
            }
        });
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);

        Activity activity = getActivity();

        if(activity instanceof Dialog) {
            ((Dialog)activity).dialogClose(dialog);
        }
    }


}
