package com.example.agentiedam.Model;

import java.io.Serializable;

public class ProfilModel implements Serializable {
    String facultate;
    String an;
    int grupa;
    String disciplina;
    String temaProiect;

    public ProfilModel() {

    }

    public ProfilModel(String facultate, String an, int grupa, String disciplina, String temaProiect) {
        this.facultate = facultate;
        this.an = an;
        this.grupa = grupa;
        this.disciplina = disciplina;
        this.temaProiect = temaProiect;
    }

    @Override
    public String toString() {
        return "Profil{" +
                "facultate='" + facultate + '\'' +
                ", an='" + an + '\'' +
                ", grupa=" + grupa +
                ", disciplina='" + disciplina + '\'' +
                ", temaProiect='" + temaProiect + '\'' +
                '}';
    }

    public String getFacultate() {
        return facultate;
    }

    public void setFacultate(String facultate) {
        this.facultate = facultate;
    }

    public String getAn() {
        return an;
    }

    public void setAn(String an) {
        this.an = an;
    }

    public int getGrupa() {
        return grupa;
    }

    public void setGrupa(int grupa) {
        this.grupa = grupa;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getTemaProiect() {
        return temaProiect;
    }

    public void setTemaProiect(String temaProiect) {
        this.temaProiect = temaProiect;
    }

}
