package com.example.agentiedam;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.agentiedam.Activitati.ProfilActivity;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class IncarcareImagineAsync extends AsyncTask<Void, Void, Bitmap> {

    private Context context;
    private ProgressDialog dialog;
    private ImageView imageView;

    public IncarcareImagineAsync(Context context, ImageView imageView) {
        this.context = context;
        this.imageView = imageView;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new ProgressDialog(context);
        dialog.setMessage("Se incarca imaginea...");
        dialog.show();
    }

    @Override
    protected Bitmap doInBackground(Void... voids) {
        Bitmap bitmap = null;
        try {
            URL url = new URL("https://img.freepik.com/free-photo/person-presenting-work_1048-1747.jpg?w=740&t=st=1683239595~exp=1683240195~hmac=81fab6cde9692ad1d6a97345c6c3f7c8f433ce79cbdac55c1b26743799386ccd");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            bitmap = BitmapFactory.decodeStream(input);
        } catch (Exception e) {
            Log.e("IncarcareImagineAsync", "Eroare la descărcarea imaginii: " + e.getMessage());
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        dialog.dismiss();
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
        } else {
            Toast.makeText(context, "Eroare la descărcarea imaginii.", Toast.LENGTH_SHORT).show();
        }
    }
}
