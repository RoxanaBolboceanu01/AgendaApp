package com.example.agentiedam;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agentiedam.Activitati.AgendaActivity;
import com.example.agentiedam.BDTabele.BDAgenda;
import com.example.agentiedam.Model.AgendaModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;


public class AgendaAdapter extends RecyclerView.Adapter<AgendaAdapter.MyViewHolder> {


    Context context;
    private List<AgendaModel> aList;
    private AgendaActivity activity;
    private BDAgenda bd;
    Spinner spinner;
    FirebaseFirestore firebaseFirestore;
    private List<String> spinnerOptions = new ArrayList<String>();
    FirebaseFirestore firestore;
    FirebaseAuth auth;
    public void updateData(List<AgendaModel> newData) {
        aList = newData;
        notifyDataSetChanged();
    }


    public AgendaAdapter(AgendaActivity activity, BDAgenda bd, List<AgendaModel> aList) {
        this.activity = activity;
        this.bd = bd;
        this.aList = aList;
        spinnerOptions = bd.getSpinnerOptionsAsList();
    }

    public AgendaAdapter(BDAgenda bd, AgendaActivity activity) {
        this.bd = bd;
        this.activity = activity;
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }
    public AgendaAdapter(Context context, List<AgendaModel> list) {
        this.context = context;
        this.aList = list;
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.agenda_layout, parent, false);
        return new MyViewHolder(v);
    }



    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final AgendaModel item = aList.get(position);
        holder.checkBox.setText(item.getDescriere());
        holder.titlu.setText(item.getTitlu());
        holder.data.setText(String.valueOf(item.getData()));
        holder.descriere.setText(item.getDescriere());
        spinner = holder.itemView.findViewById(R.id.spinner);
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, spinnerOptions);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOptions.add("Selecteaza o optiune...");
        spinnerOptions.add("Scoala");
        spinnerOptions.add("Munca");
        spinnerOptions.add("Acasa");
        spinnerOptions.add("Altele..");
        spinner.setAdapter(spinnerAdapter);
        spinner.setSelection(spinnerOptions.indexOf(item.getLocatie()));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = parent.getItemAtPosition(position).toString();

                SQLiteDatabase db = null;
                try {
                    db = bd.getWritableDatabase();
                } catch (SQLException e) {
                    return;
                }

                ContentValues values = new ContentValues();
                values.put(BDAgenda.COL_7, selection);
                db.update(BDAgenda.TABLE_NAME, values, BDAgenda.COL_1 + "=?", new String[]{String.valueOf(item.getId())});

                db.close();

                updateUI();
            }

            private void updateUI() {
                SQLiteDatabase db = bd.getReadableDatabase();
                Cursor cursor = db.query(BDAgenda.TABLE_NAME, null, null, null, null, null, null);
                List<String> selections = new ArrayList<>();
                while (cursor.moveToNext()) {
                    @SuppressLint("Range") String selection = cursor.getString(cursor.getColumnIndex(BDAgenda.COL_7));
                    selections.add(selection);
                }
                cursor.close();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        firebaseFirestore = FirebaseFirestore.getInstance();

        DocumentReference documentReference = firebaseFirestore.collection("Agenda").document();

        if (holder.checkBox != null) {
            holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int status = isChecked ? 1 : 0; //status este 1 dacă este bifat, altfel este 0
                    firebaseFirestore.collection("Agenda")
                            .document(documentReference.getId())
                            .update("status", status)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                }
                            });
                }
            });
        }

        holder.checkBox.setChecked(toBoolean(item.getStatus()));
        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bd.actualizeazaStatus(item.getId(), 1);
                } else
                    bd.actualizeazaStatus(item.getId(), 0);
            }
        });

    }


    public boolean toBoolean(int num) {
        return num != 0;
    }

    public Context getContext() {
        return activity;
    }

    public void setAgenda(List<AgendaModel> aList) {
        this.aList = aList;
        notifyDataSetChanged();
    }

    public void stergeDinAgenda(int pozitie) {
        AgendaModel item = aList.get(pozitie);
        bd.sterge(item.getId());
        aList.remove(pozitie);
        notifyItemRemoved(pozitie);
    }

    public void editeaza(int pozitie) {
        AgendaModel item = aList.get(pozitie);

        Bundle bundle = new Bundle();
        bundle.putInt("id", item.getId());
        bundle.putString("titlu", item.getTitlu());
        bundle.putString("data", String.valueOf(item.getData()));
        bundle.putString("descriere", item.getDescriere());
        bundle.putString("locatie", item.getLocatie());
        AdaugaAgenda adaugaAgenda = new AdaugaAgenda();
        adaugaAgenda.setArguments(bundle);
        adaugaAgenda.show(activity.getSupportFragmentManager(), adaugaAgenda.getTag());

    }

    @Override
    public int getItemCount() {
        return aList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView titlu;
        TextView descriere;
        TextView data;
        Spinner spinner;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.check_agenda);
            titlu = itemView.findViewById(R.id.tvNume_agenda);
            descriere = itemView.findViewById(R.id.tvDescriere_agenda);
            data = itemView.findViewById(R.id.tv_agenda);
            spinner = itemView.findViewById(R.id.spinner);
        }
    }


}