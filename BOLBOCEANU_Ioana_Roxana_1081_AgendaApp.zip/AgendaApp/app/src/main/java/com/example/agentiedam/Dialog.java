package com.example.agentiedam;

import android.content.DialogInterface;

public interface Dialog {

    void dialogClose(DialogInterface dialogInterface);
}
