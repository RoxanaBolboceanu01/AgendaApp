package com.example.agentiedam.Activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.agentiedam.BDTabele.BDCont;
import com.example.agentiedam.Model.ProfilModel;
import com.example.agentiedam.R;
import com.example.agentiedam.Model.UtilizatorModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class InregistrareActivity extends AppCompatActivity {

    EditText email;
    EditText parola;
    EditText parolaConfimata;
    Button inregistrare;
    Button logare;
    BDCont bd;

    //Sincronizare online
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inregistrare);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        email = findViewById(R.id.et_email);
        parola = findViewById(R.id.et_parola);
        parolaConfimata = findViewById(R.id.et_parola2);
        inregistrare = findViewById(R.id.btn_inregistrare);
        logare = findViewById(R.id.btn_cont);

        bd = new BDCont(this);
        inregistrare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email1 = email.getText().toString();
                String parola1 = parola.getText().toString();
                String parolaConfimata1 = parolaConfimata.getText().toString();


                if (TextUtils.isEmpty(email1) || TextUtils.isEmpty(parola1) || TextUtils.isEmpty(parolaConfimata1))
                    Toast.makeText(InregistrareActivity.this, "Completeaza toate campurile", Toast.LENGTH_SHORT).show();
                else {
                    if (parola1.equals(parolaConfimata1)) {
                        Boolean verificaMail = bd.verificaEmail(email1);
                        if (verificaMail == false) {
                            Boolean insereaza = bd.insereazaDate(email1, parola1);
                            if (insereaza == true) {
                                Toast.makeText(InregistrareActivity.this, "Inregistrarea s-a realizat cu succes", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), LogareActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(InregistrareActivity.this, "Inregistrare esuata", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(InregistrareActivity.this, "Ai deja un cont ", Toast.LENGTH_SHORT).show();

                        }

                    } else {
                        Toast.makeText(InregistrareActivity.this, "Parolele nu se potrivesc", Toast.LENGTH_SHORT).show();

                    }
                }
                auth.createUserWithEmailAndPassword(email1, parola1)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    String userId = auth.getCurrentUser().getUid();
                                    UtilizatorModel utilizator = new UtilizatorModel(email1, parola1,parolaConfimata1);
                                    database.getReference("utilizatori").child(userId).setValue(utilizator);


                                    if (TextUtils.isEmpty(email1) || TextUtils.isEmpty(parola1) || TextUtils.isEmpty(parolaConfimata1))
                                        Toast.makeText(InregistrareActivity.this, "Completeaza toate campurile", Toast.LENGTH_SHORT).show();
                                    else {
                                        if (parola1.equals(parolaConfimata1)) {
                                            Boolean verificaMail = bd.verificaEmail(email1);
                                            if (verificaMail == false) {
                                                Boolean insereaza = bd.insereazaDate(email1, parola1);
                                                if (insereaza == true) {
                                                    Toast.makeText(InregistrareActivity.this, "Inregistrarea s-a realizat cu succes", Toast.LENGTH_SHORT).show();
                                                    Intent intent = new Intent(getApplicationContext(), LogareActivity.class);
                                                    startActivity(intent);
                                                } else {
                                                    Toast.makeText(InregistrareActivity.this, "Inregistrare esuata", Toast.LENGTH_SHORT).show();
                                                }
                                            } else {
                                                Toast.makeText(InregistrareActivity.this, "Ai deja un cont ", Toast.LENGTH_SHORT).show();

                                            }

                                        } else {
                                            Toast.makeText(InregistrareActivity.this, "Parolele nu se potrivesc", Toast.LENGTH_SHORT).show();

                                        }
                                    }
                                } else {
                                    Toast.makeText(InregistrareActivity.this, "Inregistrare esuata: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }

        });


        logare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LogareActivity.class);
                startActivity(intent);
            }
        });
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.meniu_profil) {
            ProfilModel profil = new ProfilModel("CSIE", "An 3", 1081, "Dispozitive si aplicatii mobile", "Agenda / sincronizare online");

            Intent intent = new Intent(this, ProfilActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("profil", profil);
            intent.putExtras(bundle);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_agenda) {
            Intent intent = new Intent(this, AgendaActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_istoric) {
            Intent intent = new Intent(this, IstoricActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_deconectare) {
            Intent intent = new Intent(this, LogareActivity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}