package com.example.agentiedam.Model;

public class UtilizatorModel {
    String email;
    String parola;
    String parolaConfirmata;

    public UtilizatorModel(String email, String parola, String parolaConfirmata) {
        this.email = email;
        this.parola = parola;
        this.parolaConfirmata = parolaConfirmata;
    }

    public UtilizatorModel(String email1, String parola1) {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getParolaConfirmata() {
        return parolaConfirmata;
    }

    public void setParolaConfirmata(String parolaConfirmata) {
        this.parolaConfirmata = parolaConfirmata;
    }
}
