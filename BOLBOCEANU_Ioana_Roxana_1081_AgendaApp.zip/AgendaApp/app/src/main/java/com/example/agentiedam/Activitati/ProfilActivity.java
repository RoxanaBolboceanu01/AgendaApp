package com.example.agentiedam.Activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.agentiedam.IncarcareImagineAsync;
import com.example.agentiedam.Model.ProfilModel;
import com.example.agentiedam.R;

public class ProfilActivity extends AppCompatActivity {
    ImageView ivProfil;
    SeekBar sbProfil ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        sbProfil = findViewById(R.id.sb_profil);
        ivProfil = findViewById(R.id.iv_async);
        TextView etFacultate = findViewById(R.id.et_facultate);
        TextView etAn = findViewById(R.id.et_an);
        TextView etGrupa = findViewById(R.id.et_grupa);
        TextView etDisciplina = findViewById(R.id.et_disciplina);
        TextView etTemaProiect = findViewById(R.id.et_temaProiect);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            ProfilModel profil = (ProfilModel) bundle.getSerializable("profil");
            etFacultate.setText(profil.getFacultate());
            etAn.setText(profil.getAn());
            etGrupa.setText(Integer.toString(profil.getGrupa()));
            etDisciplina.setText(profil.getDisciplina());
            etTemaProiect.setText(profil.getTemaProiect());

        }
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String email = extras.getString("email");
            TextView textView = findViewById(R.id.et_emailProfil);
            textView.setText(email);
        }

        IncarcareImagineAsync incarcareImagineAsync = new IncarcareImagineAsync(this, findViewById(R.id.iv_async));
        incarcareImagineAsync.execute();

        sbProfil.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // actualizați poziția și dimensiunea imaginii
                updateImagePositionAndSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });






    }

    private void updateImagePositionAndSize(int progress) {
        //dimensiunea imaginii curente
        int currentImageWidth = ivProfil.getWidth();
        int currentImageHeight = ivProfil.getHeight();

        //dimensiunea părintelui imageView
        int parentWidth = ((ViewGroup) ivProfil.getParent()).getWidth();
        int parentHeight = ((ViewGroup) ivProfil.getParent()).getHeight();

        //noua lățime și înălțime a imaginii
        int newImageWidth = (int) (parentWidth * (progress / 100f));
        int newImageHeight = (int) (currentImageHeight * ((float) newImageWidth / currentImageWidth));

        //poziția inițială a imaginii
        int imageX = ivProfil.getLeft();
        int imageY = ivProfil.getTop();

        // actualizarea dimensiunii imaginii
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) ivProfil.getLayoutParams();
        layoutParams.width = newImageWidth;
        layoutParams.height = newImageHeight;
        layoutParams.setMargins(imageX, imageY, 0, 0);
        ivProfil.setLayoutParams(layoutParams);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.meniu_profil) {
            ProfilModel profil = new ProfilModel("CSIE", "An 3", 1081, "Dispozitive si aplicatii mobile", "Agenda / sincronizare online");
            Intent intent = new Intent(this, ProfilActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("profil", profil);
            intent.putExtras(bundle);
            String email = getIntent().getStringExtra("email");
            intent.putExtra("email",email);

            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_agenda) {
            Intent intent = new Intent(this, AgendaActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_istoric) {
            Intent intent = new Intent(this, IstoricActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_deconectare) {
            Intent intent = new Intent(this, DeconectareActivity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

}