package com.example.agentiedam.Model;

import java.util.Date;

public class AgendaModel {
    private String titlu;
    private Date data;
    private String descriere;
    private int id;
    private int status;
    private String locatie;

    public AgendaModel() {
    }

    public AgendaModel(String titlu, Date data, String descriere, int id, int status) {
        this.titlu = titlu;
        this.data = data;
        this.descriere = descriere;
        this.id = id;
        this.status = status;
    }

    public AgendaModel(int id,String titlu, Date data, String descriere, String locatie, int status) {
        this.id = id;
        this.titlu = titlu;
        this.data = data;
        this.descriere = descriere;
        this.locatie = locatie;
        this.status = status;
    }

    public AgendaModel(int id, String titlu, Date data, String descriere, String locatie) {
        this.id = id;
        this.titlu = titlu;
        this.data = data;
        this.descriere = descriere;
        this.locatie = locatie;
    }

    public AgendaModel(String titlu, Date data, String descriere, String locatie) {
        this.titlu = titlu;
        this.data = data;
        this.descriere = descriere;
        this.locatie = locatie;
    }

    public String getLocatie() {
        return locatie;
    }

    public void setLocatie(String locatie) {
        this.locatie = locatie;
    }

    public String getTitlu() {
        return titlu;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "AgendaModel{" +
                "titlu='" + titlu + '\'' +
                ", data=" + data +
                ", descriere='" + descriere + '\'' +
                ", id=" + id +
                ", status=" + status +
                ", locatie='" + locatie + '\'' +
                '}';
    }
}
