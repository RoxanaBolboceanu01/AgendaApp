package com.example.agentiedam.Activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.agentiedam.BDTabele.BDCont;
import com.example.agentiedam.Preferinte;
import com.example.agentiedam.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LogareActivity extends AppCompatActivity {
    private Preferinte preferinte;
    EditText email;
    EditText parola;
    Button logare;
    BDCont bd;

    Button button;

    FirebaseAuth auth;

    Switch aSwitch;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logare);


        auth = FirebaseAuth.getInstance();
        email = findViewById(R.id.et_emailLogare);
        parola = findViewById(R.id.et_parolaLogare);
        logare = findViewById(R.id.btn_conectare);
        bd = new BDCont(this);
        preferinte = new Preferinte(getApplicationContext());
        preferinte.scrieDatePreferinte();
        preferinte.citesteDatePreferinte();

        button = findViewById(R.id.btn_cont_inreg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), InregistrareActivity.class);
                startActivity(intent);
            }
        });

        aSwitch = findViewById(R.id.switchTheme);
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(getApplicationContext(), "Controlerul a fost activat", Toast.LENGTH_SHORT).show();
                    logare.setBackgroundColor(Color.MAGENTA);
                } else {
                    Toast.makeText(getApplicationContext(), "Controlerul a fost dezactivat", Toast.LENGTH_SHORT).show();
                    logare.setBackgroundColor(Color.BLACK);

                }
            }
        });



        logare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mailLogare = email.getText().toString();
                String parolaLogare = parola.getText().toString();

                if (TextUtils.isEmpty(mailLogare) || TextUtils.isEmpty(parolaLogare)) {
                    Toast.makeText(LogareActivity.this, "Completeaza toate campurile", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean verificaMailParola = bd.verificaEmailParola(mailLogare, parolaLogare);
                    if (verificaMailParola == true) {
                        Intent intentAgenda = new Intent(LogareActivity.this, AgendaActivity.class);
                        intentAgenda.putExtra("email", mailLogare); // adaugă adresa de e-mail în intent
                        intentAgenda.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK); // șterge toate activitățile anterioare de pe stivă
                        startActivity(intentAgenda);

                    } else {
                        Toast.makeText(LogareActivity.this, "Conectare esuata", Toast.LENGTH_SHORT).show();
                    }
                }

                auth.signInWithEmailAndPassword(mailLogare, parolaLogare)
                        .addOnCompleteListener(LogareActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                } else {
                                    Toast.makeText(LogareActivity.this, "Conectare esuata", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


            }

        });



    }




}