package com.example.agentiedam.Activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RatingBar;

import com.example.agentiedam.Model.ProfilModel;
import com.example.agentiedam.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DeconectareActivity extends AppCompatActivity {

    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deconectare);



        ratingBar = findViewById(R.id.rb_deconectare);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(DeconectareActivity.this, LogareActivity.class));
                finish();
            }
        },4000);
        // Verifică dacă utilizatorul este autentificat
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference ratingsRef = FirebaseDatabase.getInstance().getReference("ratings").child(userId);
            float rating = ratingBar.getRating();

            ratingsRef.setValue(rating).addOnCompleteListener(new OnCompleteListener<Void>() {

                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Log.d("TAG", "Rating saved successfully");
                    } else {
                        Log.e("TAG", "Failed to save rating", task.getException());
                    }
                }
            });
        } else {
            Log.e("TAG", "User not authenticated");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.meniu_profil) {
            ProfilModel profil = new ProfilModel("CSIE", "An 3", 1081, "Dispozitive si aplicatii mobile", "Agenda / sincronizare online");
            Intent intent = new Intent(this, ProfilActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("profil", profil);
            intent.putExtras(bundle);
            String email = getIntent().getStringExtra("email");
            intent.putExtra("email",email);

            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_agenda) {
            Intent intent = new Intent(this, AgendaActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_istoric) {
            Intent intent = new Intent(this, IstoricActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == R.id.meniu_deconectare) {
            Intent intent = new Intent(this, DeconectareActivity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}